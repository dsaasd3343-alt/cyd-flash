@echo off
title Phone screen on PC - USB
cd /d "%~dp0scrcpy-win64-v5.0.1"
echo.
echo  1. Plug the phone with a USB cable
echo  2. On the phone tap ALLOW when it asks about USB debugging
echo.
echo  Waiting for the phone...
adb devices
echo.
echo  Starting the mirror window...
scrcpy.exe --stay-awake --max-size=1280 --window-title="My phone"
echo.
echo  Window closed. Press any key.
pause >nul

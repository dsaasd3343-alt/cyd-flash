@echo off
title Phone screen on PC - WiFi
cd /d "%~dp0scrcpy-win64-v5.0.1"
set /p IP=Type the phone IP (example 192.168.1.25): 
echo.
echo  Connecting to %IP% ...
adb connect %IP%:5555
timeout /t 2 >nul
scrcpy.exe --tcpip=%IP% --stay-awake --max-size=1280 --window-title="My phone"
echo.
echo  Window closed. Press any key.
pause >nul

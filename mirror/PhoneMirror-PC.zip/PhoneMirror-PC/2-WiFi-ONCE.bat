@echo off
title Enable wireless - do this once with the cable plugged
cd /d "%~dp0scrcpy-win64-v5.0.1"
echo.
echo  Keep the USB cable plugged in for this step only.
echo  This switches the phone to wireless mode (port 5555).
echo.
adb devices
adb tcpip 5555
echo.
echo  Done. You can unplug the cable now and use 3-WiFi.bat.
pause >nul
